Blackfire Ops (Prototype)

Welcome! 
This is an early prototype of **Blackfire Ops**, a fast-paced platformer + combat game.  
The game is still under heavy development — expect bugs, unfinished content, and placeholder assets.

🎮 How to Play
- Extract the ZIP file
- Run `BlackfireOps.exe` to launch the game
- Controls: [to be updated]

🛠️ Current Status
- Early prototype (v2024.4.8)
- Just offline page

📢 Follow Development
Want to see progress and updates?  
Follow the project on Twitter: @AngryGame_TH

📬 Feedback
Got suggestions, ideas, or found a bug?  
Feel free to contact us via Twitter: @AngryGame_TH

Thanks for playing!

— Angry Game
